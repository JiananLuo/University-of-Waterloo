#include "textprocess.h"

//see header file
TextProcessor::~TextProcessor() {}//destructor
