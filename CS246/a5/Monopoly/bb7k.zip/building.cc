#include "building.h"

using namespace std;

//see header file
string Building::getName()
{
	return this->name;
}

//see header file
Building * Building::getBuilding()
{
	return this;
}
